//     // dd($_FILES['image']);

//     //return $request->file('image');
//    // $folder = Storage::makeDirectory('public/aimeos/main_products/12');
//     foreach ($request->file('image') as  $value) {
//         # code...
//         //echo $request->file('image')[$key];
//         //  $value->store('public/aimeos/main_products');
//         $value->store('public/aimeos/main_products/');
//         //    if ($request->hasFile('image')) {
//         //     //  return $request->file('image');
//         //   } else {
//         //       return 'no';
//         //   }
//     }
//     //$name = $request->all();
// return json_decode($request['attributes'])->Brand;;
// return  json_decode($request['estimation'])->estimation;


//return json_decode($request['token']);
        //  return $checkIflogin->check_session_tokenGlocbal(json_decode($request['token']));


        // return 'ok';
            // for ($i = 0; $i < 200; $i++) {

                //  return  $add_products->id;