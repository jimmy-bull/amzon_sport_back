<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use Srmklive\PayPal\Services\PayPal as PayPalClient;

class Paypal_ extends Controller
{

    public function payp()
    {
       // $provider = new PayPalClient;

    }
}
