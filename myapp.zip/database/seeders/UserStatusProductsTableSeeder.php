<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class UserStatusProductsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('user_status_products')->delete();
        
        
        
    }
}