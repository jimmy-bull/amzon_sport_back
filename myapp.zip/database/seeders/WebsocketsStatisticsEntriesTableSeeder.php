<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class WebsocketsStatisticsEntriesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('websockets_statistics_entries')->delete();
        
        
        
    }
}