<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class AuctionDatesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('auction_dates')->delete();
        
        
        
    }
}